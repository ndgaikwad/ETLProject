class my_class:
    def printme(self):
        return "Hello World"